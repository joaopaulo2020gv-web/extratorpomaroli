#!/bin/bash
# run.sh — Script para cPanel Cron
# Executa o Python Worker de forma pontual (1 bloco por execucao)
#
# Configurar no cPanel -> Cron Jobs (a cada 2-5 minutos):
#   */2 * * * * /home/pomar2868697/extractor/run.sh >> /home/pomar2868697/logs/worker.log 2>&1
#
# Ou se o Python estiver disponivel globalmente:
#   */2 * * * * cd /home/pomar2868697/extractor && python3.11 worker.py >> /home/pomar2868697/logs/worker.log 2>&1

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

# --- Detectar Python 3 ---
PYTHON=""
for cmd in python3.11 python3.10 python3.9 python3 python; do
    if command -v "$cmd" &>/dev/null; then
        PYTHON="$cmd"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "[$(date)] ERRO: Python 3 nao encontrado no PATH"
    exit 1
fi

# --- Ativar virtualenv (se existir) ---
VENV_DIR="$SCRIPT_DIR/venv"
if [ -d "$VENV_DIR" ] && [ -f "$VENV_DIR/bin/activate" ]; then
    source "$VENV_DIR/bin/activate"
fi

# --- Executar worker (1 bloco, depois encerra) ---
PYTHON_VERSION=$($PYTHON --version 2>&1)
echo "[$(date)] Worker iniciando com $PYTHON ($PYTHON_VERSION)"
$PYTHON worker.py
EXIT_CODE=$?
echo "[$(date)] Worker finalizado com codigo: $EXIT_CODE"
exit $EXIT_CODE
