# Python Worker — Extrator Pomaroli v3.2

Worker de processamento de PDFs que roda no cPanel/Turbo Cloud via Cron.

## O que faz

- Consome jobs enfileirados no WordPress via REST API (autenticacao HMAC-SHA256)
- Processa PDFs em blocos configuraveis (default: 20 paginas)
- Salva progresso e questoes extraidas no WordPress a cada bloco
- Utiliza o `extrator.py` original para parsing deterministico (regex + maquina de estados)
- Extrai imagens de alternativas e enunciados
- Valida qualidade das questoes extraidas

## Arquivos

```
pomaroli-python-worker/
├── worker.py              # Script principal do worker (cron)
├── app.py                 # Flask app leve (health check / status)
├── extrator.py            # Logica de extracao de texto (original)
├── qualidade.py           # Validacao de qualidade
├── requirements.txt       # Dependencias Python
├── run.sh                 # Script para cPanel Cron
├── config.json.example    # Exemplo de configuracao
├── .htaccess              # Bloqueio de acesso direto
└── README.md              # Este arquivo
```

## Instalacao no cPanel

### 1. Copiar arquivos

Copie toda a pasta para o servidor via FTP/SSH:
```
/home/pomar2868697/extractor/
```

### 2. Configurar

Copie `config.json.example` para `config.json` e preencha:
```json
{
    "wordpress_url": "https://seudominio.com",
    "worker_secret": "COPIE_A_SECRET_DO_PLUGIN_WORDPRESS_AQUI",
    "gemini_api_key": "",
    "block_size": 20
}
```

O `worker_secret` deve ser o mesmo valor configurado no plugin WordPress.

**Ou** use variaveis de ambiente (recomendado):
```bash
export WP_SITE_URL="https://seudominio.com"
export POMAROLI_WORKER_SECRET="sua_secret_aqui"
export GEMINI_API_KEY=""
export BLOCK_SIZE=20
```

### 3. Instalar dependencias

```bash
cd /home/pomar2868697/extractor
pip3.11 install -r requirements.txt
```

### 4. Configurar permissoes

```bash
chmod +x run.sh
chmod 600 config.json
chmod 700 .
```

### 5. Configurar Cron no cPanel

Acesse **Cron Jobs** no cPanel e adicione:

```bash
*/2 * * * * /home/pomar2868697/extractor/run.sh >> /home/pomar2868697/logs/worker.log 2>&1
```

**Intervalo recomendado:** A cada 2 minutos. O worker processa UM bloco por execucao e libera o lock, permitindo que a proxima execucao continue de onde parou.

## Fluxo de Execucao

```
Cada tick do Cron (2 min):
  1. Verifica lock -> se ocupado, sai
  2. GET /wp-json/pomaroli/v1/worker/next-job -> busca proximo job queued
  3. POST /wp-json/pomaroli/v1/worker/claim-job -> marca como processing
  4. GET /wp-json/pomaroli/v1/jobs/{id}/files -> busca arquivos do job
  5. Para cada arquivo:
     a. Extrai texto do bloco (20 paginas) via pdfplumber
     b. Parseia questoes via extrator.parsear_questoes_local()
     c. Extrai imagens de alternativas e enunciados
     d. Valida qualidade via validar_questoes()
     e. POST /wp-json/pomaroli/v1/worker/questions -> salva questoes
     f. POST /wp-json/pomaroli/v1/worker/update -> atualiza progresso
  6. Se todos os arquivos processados -> POST /worker/complete
  7. Libera lock e encerra
```

## Debugging

```bash
# Testar manualmente
cd /home/pomar2868697/extractor
python3.11 worker.py

# Ver logs
tail -f /home/pomar2868697/logs/worker.log

# Verificar status via Flask (se rodando)
curl https://seudominio.com/worker/status
```

## Seguranca

- Autenticacao HMAC-SHA256 entre Python e WordPress
- Lock de arquivo impede execucoes concorrentes
- `.htaccess` bloqueia acesso direto aos arquivos Python
- Nunca exponha `config.json` publicamente
