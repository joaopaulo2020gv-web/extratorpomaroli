"""
app.py — Flask app WSGI para cPanel (passenger/gunicorn).

Aplicacao web leve. O worker de processamento fica em worker.py
e e chamado pelo Cron separadamente.

Uso:
  gunicorn app:app --bind 127.0.0.1:8000 --timeout 120
  ou via passenger_wsgi.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, jsonify

app = Flask(__name__)


@app.route('/')
def index():
    """Pagina inicial com informacoes do servico."""
    return jsonify({
        'service': 'Pomaroli Python Worker',
        'version': '3.2.0',
        'status': 'running',
        'endpoints': {
            '/': 'Informacoes do servico',
            '/health': 'Health check',
            '/worker/status': 'Status do worker (lock, config)',
        }
    })


@app.route('/health')
def health():
    """Health check simples."""
    return jsonify({'status': 'ok'})


@app.route('/worker/status')
def worker_status():
    """Status do worker: lock ativo, configuracao."""
    try:
        from worker import LOCK_FILE, WP_SITE_URL, WORKER_SECRET, CFG
        lock_ativo = os.path.exists(LOCK_FILE)
        return jsonify({
            'lock_ativo': lock_ativo,
            'wp_site_url_configurado': bool(WP_SITE_URL),
            'worker_secret_configurado': bool(WORKER_SECRET),
            'block_size': CFG.get('BLOCK_SIZE', 20),
        })
    except ImportError:
        return jsonify({'erro': 'worker.py nao encontrado'}), 500


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=False)
