"""
worker.py — Python Worker para processamento de PDFs via cPanel Cron.

EXECUCAO PONTUAL: cada chamada processa EXATAMENTE UM BLOCO de paginas.
O Cron e responsavel por chamar novamente.

Fluxo:
  1. Verifica lock
  2. Busca proximo job queued no WordPress (created_at ASC)
  3. Identifica o proximo arquivo pendente e sua pagina atual
  4. Processa UM BLOCO (ex: 20 paginas)
  5. Salva questoes e progresso no WordPress
  6. Libera lock e encerra

Execucao pontual: executa, processa, salva, encerra.
O WordPress e a fonte oficial de estado (current_page, status).
"""

import os
import sys
import json
import time
import hmac
import hashlib
import fcntl
import gc
import traceback

import requests

# Adiciona o diretorio atual ao path para importar extrator.py e qualidade.py
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import extrator
from qualidade import validar_questoes

# =============================================================================
# CONFIGURACAO
# =============================================================================

def load_config():
    """Carrega config de variaveis de ambiente ou config.json."""
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
    config = {}
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

    return {
        'WP_SITE_URL': os.environ.get('WP_SITE_URL', config.get('wordpress_url', '')).rstrip('/'),
        'WORKER_SECRET': os.environ.get('POMAROLI_WORKER_SECRET', config.get('worker_secret', '')),
        'GEMINI_API_KEY': os.environ.get('GEMINI_API_KEY', config.get('gemini_api_key', '')),
        'BLOCK_SIZE': int(os.environ.get('BLOCK_SIZE', config.get('block_size', 20))),
    }

CFG = load_config()
WP_SITE_URL = CFG['WP_SITE_URL']
WORKER_SECRET = CFG['WORKER_SECRET']
BLOCK_SIZE = CFG['BLOCK_SIZE']

LOCK_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.worker.lock')

# =============================================================================
# LOG
# =============================================================================

def log(msg):
    """Log com timestamp."""
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{ts}] {msg}", flush=True)

# =============================================================================
# HMAC SIGNING
# Formato: HMAC-SHA256("{timestamp}.{body}", secret)
# Compativel com Pomaroli_Worker_Auth::compute_hmac() no plugin WordPress
# =============================================================================

def sign_request(payload_str):
    """Gera headers HMAC-SHA256 para autenticacao com WordPress."""
    timestamp = str(int(time.time()))
    message = f"{timestamp}.{payload_str}"
    signature = hmac.new(
        WORKER_SECRET.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    return {
        'X-Pomaroli-Hmac': signature,
        'X-Pomaroli-Timestamp': timestamp,
        'Content-Type': 'application/json',
        'User-Agent': 'PomaroliWorker/3.3',
    }


def wp_request(method, endpoint, data=None, timeout=60):
    """Faz request autenticado ao WordPress REST API."""
    url = f"{WP_SITE_URL}/wp-json/pomaroli/v1/{endpoint}"
    body_str = json.dumps(data) if data else ''
    headers = sign_request(body_str)

    if method == 'GET':
        res = requests.get(url, headers=headers, timeout=timeout)
    elif method == 'POST':
        res = requests.post(url, data=body_str, headers=headers, timeout=timeout)
    else:
        raise ValueError(f"Method nao suportado: {method}")

    return res

# =============================================================================
# LOCK (fcntl — Linux/cPanel)
# =============================================================================

class WorkerLock:
    """Lock baseado em arquivo para impedir execucoes concorrentes."""

    def __init__(self):
        self._fd = None

    def adquirir(self):
        """Tenta adquirir o lock. Retorna True se conseguiu."""
        try:
            self._fd = open(LOCK_FILE, 'w')
            fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self._fd.write(str(os.getpid()))
            self._fd.flush()
            return True
        except (IOError, OSError):
            if self._fd:
                self._fd.close()
                self._fd = None
            return False

    def liberar(self):
        """Libera o lock. Seguro mesmo em caso de erro."""
        if self._fd:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_UN)
                self._fd.close()
            except Exception:
                pass
            self._fd = None
        try:
            if os.path.exists(LOCK_FILE):
                os.remove(LOCK_FILE)
        except Exception:
            pass

# =============================================================================
# WORDPRESS API HELPERS
# =============================================================================

def wp_get_next_job():
    """Busca o proximo job com status queued (created_at ASC).
    
    Compativel com o endpoint worker/next-job do plugin WordPress:
    WHERE status = 'queued' ORDER BY created_at ASC LIMIT 1
    """
    res = wp_request('GET', 'worker/next-job')
    if res.status_code == 200:
        data = res.json()
        if data.get('job'):
            return data['job']
    return None


def wp_claim_job(job_id):
    """Marca um job como processando (claim)."""
    res = wp_request('POST', 'worker/claim-job', {'job_id': job_id})
    return res.status_code == 200


def wp_update_job(job_id, data):
    """Atualiza dados de um job no WordPress.
    
    Retorna True apenas se HTTP 200 E JSON {'ok': true}.
    """
    data['job_id'] = job_id
    res = wp_request('POST', 'worker/update', data)
    if res.status_code != 200:
        return False
    try:
        body = res.json()
        return body.get('ok') is True
    except Exception:
        return False


def wp_save_questions(job_id, file_id, file_index, questions):
    """Envia questoes extraidas para o WordPress.
    
    Para idempotencia, o plugin WordPress utiliza create_questions_batch()
    que insere directamente. O worker deve APENAS enviar questoes novas
    (nao duplicadas) — garantido pelo controle de progresso no DB.
    """
    payload = {
        'job_id': job_id,
        'questions': [{
            'job_id': job_id,
            'file_id': file_id,
            'file_index': file_index,
            'question_number': q.get('Numero', idx + 1),
            'question_data': q,
            'status': 'extracted',
        } for idx, q in enumerate(questions)]
    }
    res = wp_request('POST', 'worker/questions', payload)
    return res.status_code == 200, res.json() if res.status_code == 200 else {}


def wp_complete_job(job_id, success=True, total_questions=0, processed_files=0, error_message=None):
    """Notifica o WordPress que o job foi finalizado."""
    payload = {
        'job_id': job_id,
        'success': success,
        'total_questions': total_questions,
        'processed_files': processed_files,
        'error_message': error_message,
    }
    res = wp_request('POST', 'worker/complete', payload)
    return res.status_code == 200


def wp_get_job_files(job_id):
    """Busca os arquivos de um job no WordPress (via rota HMAC do worker)."""
    res = wp_request('GET', f'worker/files/{job_id}')
    if res.status_code == 200:
        data = res.json()
        return data.get('files', [])
    return []

# =============================================================================
# EXTRACAO DE TEXTO (bloco unico)
# =============================================================================

def extrair_bloco_texto(caminho_pdf, bloco_inicio, bloco_fim):
    """Extrai texto de um bloco especifico de paginas do PDF usando pdfplumber."""
    import pdfplumber

    texto_bloco = []
    try:
        with pdfplumber.open(caminho_pdf) as pdf:
            total = len(pdf.pages)
            for i in range(bloco_inicio, min(bloco_fim, total)):
                page = pdf.pages[i]
                txt = page.extract_text() or ""
                if txt.strip():
                    texto_bloco.append(txt)
    except Exception as e:
        log(f"ERRO ao extrair bloco {bloco_inicio}-{bloco_fim}: {e}")
        return None

    return '\n\n'.join(texto_bloco)


def extrair_bloco_com_ocr(caminho_pdf, bloco_inicio, bloco_fim, api_key, model):
    """Extrai texto de um bloco usando OCR via Gemini Vision."""
    import fitz  # PyMuPDF
    import tempfile

    texto_bloco = []
    try:
        doc = fitz.open(caminho_pdf)
        total = len(doc)

        for i in range(bloco_inicio, min(bloco_fim, total)):
            page = doc.load_page(i)
            pix = page.get_pixmap(dpi=200)
            img_bytes = pix.tobytes("png")

            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                tmp.write(img_bytes)
                tmp_path = tmp.name

            try:
                texto = extrator.extrair_texto_por_ocr(
                    tmp_path,
                    provedor='gemini',
                    api_key=api_key,
                    model=model or 'gemini-2.0-flash',
                    endpoint=None
                )
                if texto:
                    texto_bloco.append(texto)
            finally:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)

        doc.close()
    except Exception as e:
        log(f"ERRO OCR bloco {bloco_inicio}-{bloco_fim}: {e}")
        return None

    return '\n\n'.join(texto_bloco)


def contar_paginas_pdf(caminho_pdf):
    """Conta o total de paginas de um PDF."""
    import pdfplumber
    try:
        with pdfplumber.open(caminho_pdf) as pdf:
            return len(pdf.pages)
    except Exception:
        return 0

# =============================================================================
# PROCESSAMENTO DE UM UNICO BLOCO
# =============================================================================

def processar_um_bloco(job, file):
    """
    Processa EXATAMENTE UM BLOCO de paginas de UM arquivo.
    
    Lee current_page do DB (file['current_page']), processa BLOCK_SIZE paginas,
    salva questoes e progresso, e retorna.
    
    Retorna: (bloco_processado, total_questoes_bloco, arquivo_concluido, erro)
    """
    job_id = job['id']
    file_id = file['id']
    file_index = file.get('file_index', 0)
    caminho_pdf = file.get('file_path', '')
    filename = file.get('filename', '')

    use_ocr = bool(job.get('use_ocr', 0))
    api_key = CFG['GEMINI_API_KEY']
    ocr_model = job.get('ai_model', 'gemini-2.0-flash')

    # ------------------------------------------------------------------
    # 1. Determinar de onde continuar (resume via DB)
    # ------------------------------------------------------------------
    current_page = int(file.get('current_page', 0))
    total_paginas = int(file.get('pages', 0))

    # Se total_pages nao foi salvo ainda, contar
    if total_paginas == 0:
        total_paginas = contar_paginas_pdf(caminho_pdf)
        if total_paginas == 0:
            wp_update_job(job_id, {
                'file_id': file_id,
                'file_status': 'failed',
                'error_message': 'PDF sem paginas ou corrompido.',
            })
            return False, 0, True, True

        wp_update_job(job_id, {'total_pages': total_paginas})

    # Verificar se o arquivo ja foi concluido
    if current_page >= total_paginas:
        return False, 0, True, False

    # ------------------------------------------------------------------
    # 2. Calcular o bloco a processar
    # ------------------------------------------------------------------
    bloco_inicio = current_page
    bloco_fim = min(bloco_inicio + BLOCK_SIZE, total_paginas)
    bloco_num = (bloco_inicio // BLOCK_SIZE) + 1
    total_blocos = (total_paginas + BLOCK_SIZE - 1) // BLOCK_SIZE

    log(f"[BLOCO {bloco_num}/{total_blocos}] {filename}: paginas {bloco_inicio+1}-{bloco_fim} de {total_paginas}")

    # ------------------------------------------------------------------
    # 3. Extrair texto do bloco
    # ------------------------------------------------------------------
    if use_ocr and api_key:
        texto = extrair_bloco_com_ocr(caminho_pdf, bloco_inicio, bloco_fim, api_key, ocr_model)
    else:
        texto = extrair_bloco_texto(caminho_pdf, bloco_inicio, bloco_fim)

    if texto is None:
        log(f"ERRO ao extrair texto do bloco {bloco_inicio+1}-{bloco_fim}")
        wp_update_job(job_id, {
            'file_id': file_id,
            'file_status': 'failed',
            'error_message': f'Erro ao extrair texto do bloco {bloco_inicio+1}-{bloco_fim}.',
        })
        return False, 0, True, True

    if not texto.strip():
        log(f"Bloco vazio (paginas {bloco_inicio+1}-{bloco_fim}), avancando...")
        # Avanca o progresso mesmo para blocos vazios
        novo_current = bloco_fim
        progresso = int((novo_current / total_paginas) * 100) if total_paginas > 0 else 0
        arquivo_concluido = novo_current >= total_paginas

        progresso_ok = wp_update_job(job_id, {
            'file_id': file_id,
            'file_current_page': novo_current,
            'file_progress': progresso,
            'current_page': novo_current,
            'progress': progresso,
        })

        if not progresso_ok:
            log("ERRO ao atualizar progresso (bloco vazio) — bloco NAO avancado")
            del texto
            gc.collect()
            return False, 0, False, True

        if arquivo_concluido:
            wp_update_job(job_id, {
                'file_id': file_id,
                'file_status': 'completed',
                'file_progress': 100,
            })

        del texto
        gc.collect()
        return True, 0, arquivo_concluido, False

    # ------------------------------------------------------------------
    # 4. Parsear questoes do bloco
    # ------------------------------------------------------------------
    questoes = extrator.parsear_questoes_local(texto)
    log(f"{len(questoes)} questoes encontradas no bloco")

    # ------------------------------------------------------------------
    # 5. Extrair imagens e validar
    # ------------------------------------------------------------------
    if questoes:
        questoes = extrator.extrair_imagens_alternativas_pdf(caminho_pdf, questoes)
        questoes = extrator.extrair_imagens_enunciado_pdf(caminho_pdf, questoes)
        questoes = validar_questoes(questoes)

    # ------------------------------------------------------------------
    # 6. Salvar questoes no WordPress (idempotente)
    # ------------------------------------------------------------------
    questoes_salvas = 0
    if questoes:
        ok, _ = wp_save_questions(job_id, file_id, file_index, questoes)
        if ok:
            questoes_salvas = len(questoes)
            log(f"{questoes_salvas} questoes salvas no WordPress")
        else:
            log("ERRO ao salvar questoes no WordPress — bloco NAO avancado")
            del texto, questoes
            gc.collect()
            return False, 0, False, True

    # ------------------------------------------------------------------
    # 7. Atualizar progresso no WordPress (somente se questoes salvas OK)
    # ------------------------------------------------------------------
    novo_current = bloco_fim
    progresso = int((novo_current / total_paginas) * 100) if total_paginas > 0 else 0
    arquivo_concluido = novo_current >= total_paginas

    progresso_ok = wp_update_job(job_id, {
        'file_id': file_id,
        'file_current_page': novo_current,
        'file_progress': progresso,
        'file_pages': total_paginas,
        'file_questions_found': int(file.get('questions_found', 0)) + questoes_salvas,
        'current_page': novo_current,
        'progress': progresso,
    })

    if not progresso_ok:
        log("ERRO ao atualizar progresso no WordPress — bloco NAO avancado")
        del texto, questoes
        gc.collect()
        return False, questoes_salvas, False, True

    if arquivo_concluido:
        file_complete_ok = wp_update_job(job_id, {
            'file_id': file_id,
            'file_status': 'completed',
            'file_progress': 100,
        })
        if file_complete_ok:
            log(f"Arquivo {filename} CONCLUIDO: {total_paginas} paginas, {int(file.get('questions_found', 0)) + questoes_salvas} questoes totais")
        else:
            log(f"AVISO: Falha ao marcar arquivo {filename} como completed")

    # ------------------------------------------------------------------
    # 8. Liberar memoria
    # ------------------------------------------------------------------
    del texto, questoes
    gc.collect()

    return True, questoes_salvas, arquivo_concluido, False

# =============================================================================
# EXECUCAO PRINCIPAL (1 bloco por chamada)
# =============================================================================

def run_worker():
    """
    Execucao PONTUAL do worker.
    
    Processa EXATAMENTE UM BLOCO de UM ARQUIVO de UM JOB.
    Depois salva progresso e encerra.
    
    Fluxo:
      1. Verifica lock
      2. Busca proximo job queued (created_at ASC)
      3. Identifica proximo arquivo pendente
      4. Processa UM bloco
      5. Salva progresso
      6. Libera lock
      7. Encerra
    """
    # ------------------------------------------------------------------
    # Validacoes
    # ------------------------------------------------------------------
    if not WP_SITE_URL:
        log("ERRO: WP_SITE_URL nao configurado.")
        return {'status': 'error', 'message': 'WP_SITE_URL nao configurado.'}, 500

    if not WORKER_SECRET:
        log("ERRO: POMAROLI_WORKER_SECRET nao configurado.")
        return {'status': 'error', 'message': 'POMAROLI_WORKER_SECRET nao configurado.'}, 500

    # ------------------------------------------------------------------
    # Lock
    # ------------------------------------------------------------------
    lock = WorkerLock()
    if not lock.adquirir():
        log("Outro worker ja esta em execucao. Saindo.")
        return {'status': 'busy', 'message': 'Outro worker ja esta em execucao.'}, 200

    job_id = None
    try:
        # ------------------------------------------------------------------
        # Buscar proximo job (created_at ASC = mais antigo primeiro)
        # ------------------------------------------------------------------
        job = wp_get_next_job()
        if not job:
            log("Nenhum job na fila.")
            return {'status': 'idle', 'message': 'Nenhum job na fila.'}, 200

        job_id = job['id']

        # Claim job (marcar como processando)
        claimed = wp_claim_job(job_id)
        if not claimed:
            log(f"ERRO: Nao foi possivel claim job #{job_id}.")
            return {'status': 'error', 'message': f'Nao foi possivel claim job #{job_id}.'}, 500

        log(f"Job #{job_id} claimado. Buscando arquivos...")

        # ------------------------------------------------------------------
        # Buscar arquivos do job
        # ------------------------------------------------------------------
        files = wp_get_job_files(job_id)
        if not files:
            wp_complete_job(job_id, success=False, error_message='Nenhum arquivo encontrado.')
            return {'status': 'error', 'message': 'Nenhum arquivo encontrado.'}, 404

        # ------------------------------------------------------------------
        # Encontrar o proximo arquivo pendente ou em processamento
        # ------------------------------------------------------------------
        # Prioridade: 'pending' (nunca comecou) > 'processing' (em andamento) > 'failed' (retry)
        arquivo_alvo = None
        for f in files:
            st = f.get('status', 'pending')
            if st in ('pending', 'queued'):
                arquivo_alvo = f
                break
            elif st == 'processing':
                arquivo_alvo = f
                break

        if not arquivo_alvo:
            # Verificar se ha arquivos com erro para retry
            for f in files:
                if f.get('status') == 'failed':
                    arquivo_alvo = f
                    break

        if not arquivo_alvo:
            # Todos os arquivos ja foram processados
            wp_complete_job(job_id, success=True, processed_files=len(files))
            log(f"Job #{job_id}: todos os arquivos ja processados. Finalizando.")
            return {'status': 'completed', 'message': 'Todos os arquivos ja processados.'}, 200

        # ------------------------------------------------------------------
        # Verificar se o arquivo tem PDF valido
        # ------------------------------------------------------------------
        caminho_pdf = arquivo_alvo.get('file_path', '')
        if not caminho_pdf or not os.path.exists(caminho_pdf):
            log(f"Arquivo nao encontrado: {caminho_pdf}")
            wp_update_job(job_id, {
                'file_id': arquivo_alvo['id'],
                'file_status': 'failed',
                'error_message': f'Arquivo nao encontrado: {caminho_pdf}',
            })
            # Nao retorna erro — proxima execucao pega o proximo arquivo
            return {
                'status': 'file_error',
                'job_id': job_id,
                'message': f'Arquivo nao encontrado: {caminho_pdf}',
            }, 200

        # ------------------------------------------------------------------
        # Marcar arquivo como processando
        # ------------------------------------------------------------------
        if arquivo_alvo.get('status') != 'processing':
            wp_update_job(job_id, {
                'file_id': arquivo_alvo['id'],
                'file_status': 'processing',
            })

        # ------------------------------------------------------------------
        # PROCESSAR EXATAMENTE UM BLOCO
        # ------------------------------------------------------------------
        bloco_ok, questoes_bloco, arquivo_concluido, erro = processar_um_bloco(job, arquivo_alvo)

        # ------------------------------------------------------------------
        # Atualizar totais do job
        # ------------------------------------------------------------------
        # Recarregar status dos arquivos apos processamento
        files_updated = wp_get_job_files(job_id)
        if files_updated:
            files = files_updated

        arquivos_completed = sum(1 for f in files if f.get('status') == 'completed')
        arquivos_failed = sum(1 for f in files if f.get('status') == 'failed')
        arquivos_total = len(files)

        wp_update_job(job_id, {
            'processed_files': arquivos_completed + arquivos_failed,
        })

        # ------------------------------------------------------------------
        # Verificar se o job inteiro foi concluido
        # Somente completed = todos os arquivos em 'completed'
        # Se qualquer arquivo estiver 'failed', o job NAO e completed
        # ------------------------------------------------------------------
        if arquivo_concluido:
            arquivos_completed += 1

        todos_completed = arquivos_completed >= arquivos_total
        tem_falha = arquivos_failed > 0

        if todos_completed and not tem_falha:
            wp_complete_job(
                job_id,
                success=True,
                processed_files=arquivos_completed,
            )
            log(f"Job #{job_id} CONCLUIDO: todos os {arquivos_total} arquivos processados com sucesso.")
            status = 'completed'
        elif tem_falha:
            wp_complete_job(
                job_id,
                success=False,
                processed_files=arquivos_completed,
                error_message=f'{arquivos_failed} arquivo(s) com falha.',
            )
            log(f"Job #{job_id} FINALIZADO COM FALHA: {arquivos_failed} arquivo(s) com erro.")
            status = 'failed'
        else:
            status = 'partial'

        return {
            'status': status,
            'job_id': job_id,
            'file_id': arquivo_alvo['id'],
            'questoes_bloco': questoes_bloco,
            'arquivo_concluido': arquivo_concluido,
            'arquivos_processados': arquivos_processados,
            'total_arquivos': total_files,
            'message': f'Job #{job_id}: bloco processado, {questoes_bloco} questoes.',
        }, 200

    except Exception as e:
        traceback.print_exc()
        log(f"ERRO inesperado: {e}")
        if job_id:
            try:
                wp_complete_job(job_id, success=False, error_message=str(e))
            except Exception:
                pass
        return {'status': 'error', 'message': str(e)}, 500

    finally:
        # SEMPRE liberar o lock, mesmo em caso de erro
        lock.liberar()
        log("Lock liberado.")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    log("=== Pomaroli Worker v3.3.1 ===")
    log(f"WP_SITE_URL: {WP_SITE_URL or '(nao configurado)'}")
    log(f"BLOCK_SIZE: {BLOCK_SIZE}")

    resultado, status_code = run_worker()
    log(f"Resultado: {json.dumps(resultado, ensure_ascii=False)}")
    sys.exit(0 if status_code in (200, 204) else 1)
