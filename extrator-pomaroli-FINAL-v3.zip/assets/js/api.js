/**
 * PomaroliAPI — Camada de comunicação REST com o WordPress.
 * Fornece métodos para todas as operações do dashboard.
 * Upload e processamento são 100% WordPress (sem dependência de Python externo).
 */
const PomaroliAPI = (() => {
    const BASE = () => window.APP_CONFIG.restUrl;
    const HEADERS = () => ({
        'Content-Type': 'application/json',
        'X-WP-Nonce': window.APP_CONFIG.restNonce,
    });

    // ---------- helpers ----------

    async function _get(path, params = {}) {
        const url = new URL(BASE() + path, window.location.origin);
        Object.entries(params).forEach(([k, v]) => {
            if (v !== '' && v !== null && v !== undefined) url.searchParams.set(k, v);
        });
        const res = await fetch(url.toString(), { headers: HEADERS(), credentials: 'same-origin' });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ message: res.statusText }));
            throw new Error(err.message || `HTTP ${res.status}`);
        }
        return res.json();
    }

    async function _post(path, body = {}) {
        const res = await fetch(BASE() + path, {
            method: 'POST',
            headers: HEADERS(),
            credentials: 'same-origin',
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ message: res.statusText }));
            throw new Error(err.message || `HTTP ${res.status}`);
        }
        return res.json();
    }

    async function _put(path, body = {}) {
        const res = await fetch(BASE() + path, {
            method: 'PUT',
            headers: HEADERS(),
            credentials: 'same-origin',
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ message: res.statusText }));
            throw new Error(err.message || `HTTP ${res.status}`);
        }
        return res.json();
    }

    async function _delete(path) {
        const res = await fetch(BASE() + path, {
            method: 'DELETE',
            headers: HEADERS(),
            credentials: 'same-origin',
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({ message: res.statusText }));
            throw new Error(err.message || `HTTP ${res.status}`);
        }
        return res.json();
    }

    // ---------- JOBS ----------

    function listJobs(params = {}) {
        return _get('jobs', params);
    }

    function getJob(id) {
        return _get(`jobs/${id}`);
    }

    function createJob(data) {
        return _post('jobs', data);
    }

    function deleteJob(id) {
        return _delete(`jobs/${id}`);
    }

    function retryJob(id) {
        return _post(`jobs/${id}/retry`);
    }

    function getJobFiles(id) {
        return _get(`jobs/${id}/files`);
    }

    // ---------- QUESTIONS ----------

    function listQuestions(params = {}) {
        return _get('questions', params);
    }

    function getQuestion(id) {
        return _get(`questions/${id}`);
    }

    function updateQuestion(id, data) {
        return _put(`questions/${id}`, data);
    }

    function reviewQuestion(id, action, questionData = null) {
        const body = { action };
        if (questionData) body.question_data = questionData;
        return _post(`questions/${id}/review`, body);
    }

    function importQuestionsToWP(questionIds) {
        return _post('questions/import-to-wp', { question_ids: questionIds });
    }

    // ---------- STATS ----------

    function getStats() {
        return _get('stats');
    }

    // ---------- SETTINGS ----------

    function getSettings() {
        return _get('settings');
    }

    function saveSettings(data) {
        return _post('settings', data);
    }

    // ---------- LOGS ----------

    function getLogs(params = {}) {
        return _get('logs', params);
    }

    // ---------- AI JOBS ----------

    function createAIJob(data) {
        return _post('ai-jobs', data);
    }

    function getAIJob(id) {
        return _get(`ai-jobs/${id}`);
    }

    // ---------- AUTH CHECK ----------

    async function checkAuth() {
        try {
            const res = await fetch(BASE().replace('pomaroli/v1/', 'pomaroli/v1/stats'), {
                headers: HEADERS(),
                credentials: 'same-origin',
            });
            return res.ok;
        } catch {
            return false;
        }
    }

    // ---------- UPLOAD LOCAL (WordPress nativo) ----------

    async function uploadLocal(files, options = {}) {
        const formData = new FormData();
        files.forEach(f => formData.append('files[]', f));

        if (options.use_ocr) formData.append('use_ocr', '1');
        if (options.autocorrect) formData.append('use_ai', '1');
        if (options.ai_provider) formData.append('ai_provider', options.ai_provider);
        if (options.ai_model) formData.append('ai_model', options.ai_model);

        const res = await fetch(BASE() + 'upload-local', {
            method: 'POST',
            headers: { 'X-WP-Nonce': window.APP_CONFIG.restNonce },
            credentials: 'same-origin',
            body: formData,
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({ message: res.statusText }));
            throw new Error(err.message || `Upload falhou: HTTP ${res.status}`);
        }

        return res.json();
    }

    // ---------- QUEUE ----------

    function getQueueStatus() {
        return _get('queue/status');
    }

    // ---------- HEALTH ----------

    function getHealth() {
        return _get('health');
    }

    // ---------- PUBLIC API ----------

    return {
        listJobs,
        getJob,
        createJob,
        deleteJob,
        retryJob,
        getJobFiles,
        listQuestions,
        getQuestion,
        updateQuestion,
        reviewQuestion,
        importQuestionsToWP,
        getStats,
        getSettings,
        saveSettings,
        getLogs,
        createAIJob,
        getAIJob,
        checkAuth,
        uploadLocal,
        getQueueStatus,
        getHealth,
    };
})();
